"use strict"

/* Click du bouton*/

function recupMail(){
    alert("boom");
}

var bout = document.getElementById('bout'); /*var bout = $('input');*/
$('#bout').click(function(){
    var test = $('#email').val();
    var test2 = $('#email2').val();
    var test3 = $('#email3').val();
    var test4 = $('#email4').val();
    console.log(test);
    console.log(test2);
    console.log(test3);
    console.log(test4);
});

/*var bout2 = document.querySelector('.mail');
console.log(bout2);

bout.addEventListener("click",recupMail);*/

/*Recupurer les input*/

/*Met dans une variable*/